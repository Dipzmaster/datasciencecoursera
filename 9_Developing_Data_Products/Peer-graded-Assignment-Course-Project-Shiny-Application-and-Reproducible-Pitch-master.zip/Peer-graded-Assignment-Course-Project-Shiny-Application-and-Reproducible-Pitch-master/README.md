# Peer-graded-Assignment-Course-Project-Shiny-Application-and-Reproducible-Pitch
Peer-graded Assignment: Course Project: Shiny Application and Reproducible Pitch

This peer assessed assignment has two parts. 

First, you will create a Shiny application and deploy it on Rstudio's servers. 

Second, you will use Slidify or Rstudio Presenter to prepare a reproducible pitch presentation about your application.

Click the Below Link for the Application.

https://bkarmay.shinyapps.io/PricePredictorForDiamonds/

Click the Below Link for the Rpubs presentation.

http://rpubs.com/bkarmay/338599

